#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
@date: 2015-11-01
@author: Shell.Xu
@copyright: 2015, Shell.Xu <shell909090@gmail.com>
@license: cc
'''
import os

def test(basepath):
    a = raw_input('xx')
    a = int(a)
    raise ValueError()

def main():
    try:
        test(None)
    except ValueError:
        

if __name__ == '__main__': main()
