#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
@date: 2015-10-25
@author: Shell.Xu
@copyright: 2015, Shell.Xu <shell909090@gmail.com>
@license: cc
'''

# def add(l, i=0):
#     return sum(l) + i

# add = lambda a, b: a + b

# l = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# d = {1: 3, 2: 4}

# add = lambda x, y: x + y
# print add(1, 2)

# print reduce(lambda x, y: x * y, [1,2,3,4,5])

# def reduce(function, l):
#     while len(l) > 1:
#         a = l.pop(0)
#         b = l.pop(0)
#         c = function(a, b)
#         l.insert(0, c)
#     return l[0]

# def reduce(function, l, inital):
#     r = inital
#     for i in l:
#         r = function(r, i)
#     return r

# import math
# def x2(a, b, c):
#     x = math.sqrt(b*b - 4*a*c)
#     return (-b+x) / (2*a), (-b-x) / (2*a)

# print x2(2, 7, 3)
