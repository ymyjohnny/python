#!/usr/bin/python
# -*- coding: utf-8 -*-

# num = 0
# for line in s.splitlines():
#         for chunk1 in line.split(u'，'):
#                 for chunk2 in chunk1.split(u'。'):
#                         chunk2 = chunk2.strip()
#                         if chunk2.startswith(u'但是'):
#                                 print chunk2
#                                 num += 1

def split_and_extand(sep, chunks):
        result = []
        for chunk in chunks:
                result.extend(chunk.split(sep))
        return result

def splits(s, seps):
        result = [s,]
        for i in seps:
                result = split_and_extand(i, result)
        return result

# result = [s,]
# result = split_and_extand(u'\n', result)
# result = split_and_extand(u'，', result)
# result = split_and_extand(u'。', result)
# result = split_and_extand(u'"', result)

f = open('少年pi的奇幻漂流 中文版.txt')
s = f.read().decode('utf-8')
result = splits(s, u'\n，。"')
result = [chunk.strip() for chunk in result]
result = [chunk for chunk in result if chunk.startswith(u'但是')]

num = len(result)
print num

# 0基础入门书：

# A Byte of Python
# http://www.swaroopch.com/notes/python/
# 简明 Python 教程
# http://woodpecker.org.cn/abyteofpython_cn/chinese/

# 与孩子一起学编程 (书籍，需要购买)

# python参考书：

# Dive Into Python (建议有编程基础的参考)
# http://www.diveintopython.net/
# http://woodpecker.org.cn/diveintopython/

# Learn Python The Hard Way, 2nd Edition
# http://learnpythonthehardway.org/book/

# python哲学：

# Python 编程艺术 (建议经常)
# http://www.slideshare.net/wilhelmshen/py-art
