#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
@date: 2015-11-01
@author: Shell.Xu
@copyright: 2015, Shell.Xu <shell909090@gmail.com>
@license: cc
'''
import os, sys
import re
from os import path

def allfile(root):
    filepathes = []
    for base, dirs, files in os.walk(root):
        for filename in files:
            filepathes.append(path.join(base, filename))
    return filepathes

def grepfile(filepath, regex):
    f = open(filepath)
    for line in f:
        m = regex.match(line)
        if not m:
            continue
        sys.stdout.write(filepath + ': ' + line)
    f.close()

def main():
    filepathes = allfile(sys.argv[1])
    regex = re.compile(sys.argv[2])
    for filepath in filepathes:
        grepfile(filepath, regex)

if __name__ == '__main__': main()
