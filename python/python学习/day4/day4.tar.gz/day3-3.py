#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
@date: 2015-11-01
@author: Shell.Xu
@copyright: 2015, Shell.Xu <shell909090@gmail.com>
@license: cc
'''
import re

def grep_a(filepath, regex):
    f = open(filepath)
    source = f.read()
    f.close()
    return list(regex.findall(source))

def split1(s):
    result = []
    quota = False
    trans = False
    x = ''
    for c in s:
        if c == ' ' and not quota:
            result.append(x)
            x = ''
            continue
        elif c == '"' and not trans:
            quota = not quota
        trans = False
        if c == '\\':
            trans = True
        x += c
    if x:
        result.append(x)
    return result

def split_label(label):
    attrs = {}
    for attrstr in split1(label.strip()[3:-1]):
        r = attrstr.split('=', 1)
        if len(r) < 2:
            continue
        k, v = r
        v = v.strip('" ')
        attrs[k] = v
    return attrs

def main():
    regex = re.compile('<a[^>]*>', re.M)
    for label in grep_a('chardet.html', regex):
        attrs = split_label(label)
        if 'href' in attrs:
            print attrs['href']

if __name__ == '__main__': main()
