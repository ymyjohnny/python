#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
@date: 2015-10-25
@author: Shell.Xu
@copyright: 2015, Shell.Xu <shell909090@gmail.com>
@license: cc
'''

def split_and_extand(sep, chunks):
        result = []
        for chunk in chunks:
                result.extend(chunk.split(sep))
        return result

def splits(s, seps):
        result = [s,]
        for i in seps:
                result = split_and_extand(i, result)
        return result

f = open('少年pi的奇幻漂流 中文版.txt')
def procx(f):
        s = f.read().decode('utf-8')
        result = splits(s, u'\n，。"')
        result = [chunk.strip() for chunk in result]
        result = [chunk for chunk in result if chunk.startswith(u'但是')]
        return len(result)

class FileObject:

    def __init__(self, s):
        self.s = s

    def read(self):
        return self.s

    def readlines(self):
        return self.s.splitlines()

# print procx(FileObject('但是，可是，也许，但是'))
f = FileObject('a\nb\nc')
for i in f.readlines():
    print i
