#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
@date: 2015-10-25
@author: Shell.Xu
@copyright: 2015, Shell.Xu <shell909090@gmail.com>
@license: cc
'''

def main():
    start = 1
    end = 1001
    while True:
        current = (start + end) / 2
        i = raw_input('is number %d?' % current)
        if i == 'quit':
            return
        elif i == 'big':
            end = current
        elif i == 'small':
            start = current + 1
        elif i == 'eq':
            print current
            return

if __name__ == '__main__': main()
