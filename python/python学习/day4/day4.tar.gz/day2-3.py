#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
@date: 2015-10-25
@author: Shell.Xu
@copyright: 2015, Shell.Xu <shell909090@gmail.com>
@license: cc
'''

def add(*l):
    return sum(l)

# class A:
#     a = 10
#     name = 'str_a'
#     def mmx(self, b):
#         print self.name, b

# class D(A):
#     name = 'str_d'

# a = A()
# a.a = 20
# a.name = 'bob'
# d = D()

# # a.mmx(10)

# d.mmx(20)

# class R:

#     def __init__(self, a, b):
#         self.a = a
#         self.b = b

#     def check(self):
#         return ''.join(list(reversed(self.a))) == self.b

# r = R('abcdef', 'fedcba')
# print r.a
# print r.b
# # r.b = '123456'
# print r.check()

# c = Cauchy(1,2,3)
# d = c.append(4)
# e = d.append(5)
# print e.call(add) # 15

class Cauchy:
    
    def __init__(self, function):
        self.function = function
        self.l = list()

    def __call__(self, n=None):
        if n is None:
            return self.function(*self.l)
        self.l.append(n)
        return self

a = Cauchy(add)
print a.l
a(1)
print a.l
a(2)
print a.l
a(3)
print a.l
a(4)
print a.l
a(5)
print a.l
print a()

class Iter:

    def __init__(self, l):
        pass

    def next(self):
        return self.l.pop()

l = [1,2,3,4,5]
i = l.__iter__()

# i = Iter([1,2,3,4,5])
print i.next()
print i.next()
print i.next()
print i.next()
print i.next()

print l

# l.append(4)
# l.append(5)
# print add(*l)

# class A:
#     def __call__(self, a, b, c):
#         return a + b + c
# a = A()
# print a(1,2,3)

l = [1,2,3,4,5]
def addn(n):
    return lambda x: x + n
print map(addn(4), l)
